package kz.bitlab.springboot.techboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
